// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
//import { getAnalytics } from "firebase/analytics";
import { getStorage } from "firebase/storage";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyC1kU-tU0HabqEWOkSMjCZDICF_TqbS5hI",
  authDomain: "my-app-74b83.firebaseapp.com",
  projectId: "my-app-74b83",
  storageBucket: "my-app-74b83.appspot.com",
  messagingSenderId: "732190339908",
  appId: "1:732190339908:web:8c1068a6d0faffacc95d11",
  measurementId: "G-LKJCQ2PEQ5"
};

// Initialize Firebase
//const analytics = getAnalytics(app);
export const app = initializeApp(firebaseConfig);
export const auth =getAuth();
export const storage = getStorage();
export const db = getFirestore()